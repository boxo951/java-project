
package molegame;

import java.awt.BorderLayout;
import java.awt.Container;

import javax.swing.JFrame;

public class MoleGame extends JFrame { // Main Design
	Container cp;
	View v;

	public MoleGame() {
		v = new View();
		add(v);
		setTitle("Mole Game");
		setSize(400, 500);
		setVisible(true);

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		cp = getContentPane();
		cp.add(v, BorderLayout.CENTER);

	}

	public static void main(String[] args) {

		MoleGame game = new MoleGame();
	}

}
