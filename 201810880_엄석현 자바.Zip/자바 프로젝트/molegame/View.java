
package molegame;

import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.Timer;

public class View extends JPanel implements ActionListener, MouseListener {
	public static final int CW = 400;
	public static final int CH = 500;
	Mole m;
	Timer t1, t2;
	int mscore;
	int playTime;

	public View() {
		m = new Mole();
		t1 = new Timer(800, this);
		t1.start();
		mscore = 0;
		addMouseListener(this);
		playTime = 20;
		t2 = new Timer(1000, this);
		t2.start();
	}

	public void paint(Graphics g) {
		paintComponent(g);

		m.myPaint(g);
		g.drawString("Score :" + mscore, 10, 20);
		g.drawString("Time :" + playTime, 10, 35);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == t1) {
			m.moveNext();
			repaint();
		} else if (e.getSource() == t2) {
			playTime--;
			repaint();
			if (playTime <= 0) {
				t1.stop();
				t2.stop();
				JOptionPane.showMessageDialog(this, "Game Over", "info", JOptionPane.INFORMATION_MESSAGE);
			}
		}

	}

	@Override
	public void mouseClicked(MouseEvent e) {

	}

	@Override
	public void mousePressed(MouseEvent e) {
		int score;
		if (playTime <= 0)
			return;
		score = m.checkScore(e.getX(), e.getY());
		if (score > 0) {
			mscore += score;
			m.moveNext();
			repaint();
		}

	}

	@Override
	public void mouseReleased(MouseEvent e) {
	}

	@Override
	public void mouseEntered(MouseEvent e) {

	}

	@Override
	public void mouseExited(MouseEvent e) {
		// throw new UnsupportedOperationException("Not supported yet."); //To change
		// body of generated methods, choose Tools | Templates.
	}
}
