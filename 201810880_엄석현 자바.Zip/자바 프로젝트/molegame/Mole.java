
package molegame;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.Random;

/**
 *
 * @author Administrator
 */
public class Mole {
	Rectangle r;
	Random rd;

	public Mole() {
		r = new Rectangle(10, 10, 50, 50);
		rd = new Random();
	}

	public void myPaint(Graphics g) {
		g.drawRect(r.x, r.y, r.width, r.height);

	}

	public void moveNext() {
		r.x = rd.nextInt(400 - 50);//
		r.y = rd.nextInt(500 - 50);
	}

	public int checkScore(int x, int y) {
		int score = 0;
		if (r.contains(x, y) == true)
			score = 1000;
		return score;
	}
}